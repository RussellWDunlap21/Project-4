//Russell Dunlap
//Dr.Woodcock
//Data-Struct
//T/Th 2:30

#include<iostream>
#include<string>
#include<fstream>
#include<algorithm>
#include<iomanip> 
using namespace std;
string readLine(istream& fin) //Read line
{
	char buff[256];
	if (fin.peek() == '\n')
	{
		fin.ignore();
	}
	fin.getline(buff, 256, '\n');
	return string(buff);
}
struct Stats
{
	int unique;
	int distinct;
	int total;
	int multiple;
};
struct Display //Displays word count
{
	string words;
	int frequency;
};
struct Percentage
{
	double distinct;
	double uniqueWords;
	double uniqueDistincts;
};
struct Node
{
	Display value;
	Node* pLeft;
	Node* pRight;
};
Node* addNode(Node* tree, Node* toAdd);
Node* add(Node* tree, Display value);
Node* addNodeFrequency(Node* tree, Node* toAdd);
Node* addFrequency(Node* tree, Display value);
Node* find(Node* tree, string name);
int countNodes(Node *root);
bool duplicate(Node *same, string word);
void display(Node* tree);
void main()
{
	Display value;
	Stats stats;
	Percentage percentage;

	Node* tree = 0;
	Node* tree2 = 0;

	stats.total = 0;
	stats.multiple = 0;
	stats.unique = 0;

	value.frequency = 0;

	int proceed = 0;
	bool eofReached = false;
	Node* result;

	string fName = "Data.txt";
	ifstream inFile(fName.c_str());

	if (!inFile) // Making sure file is there
	{
		cout << "Error, can't open file" << endl;
		exit(0);
	}
	else
	{
		while (!inFile.eof()) // Reading the file to the end
		{
			inFile >> value.words;
			eofReached = inFile.eof();
			stats.total += 1;


			if (!eofReached)//Counting words
			{
				proceed++;
			}
			if (duplicate(tree, value.words) == false) //Checking for duplicate words
			{
				tree = add(tree, value);

				if (value.frequency == 1)
				{
					stats.unique += 1;
				}
				else
				{
					stats.multiple += 1;
				}
			}
			stats.distinct = countNodes(tree);
		}
		inFile.close();
	}

	percentage.distinct = (double(stats.distinct) / double(stats.total)) * 100;
	percentage.uniqueWords = (double(stats.unique) / double(stats.total)) * 100;
	percentage.uniqueDistincts = (double(stats.unique) / double(stats.distinct)) * 100;
	string choiceStr;
	char choice;

	do //GUI
	{
		cout << endl;
		cout << "--------------------------------" << endl;
		cout << "|  a - Display alphabetic list |" << endl;
		cout << "|  f - Display frequency list  |" << endl;
		cout << "|  s - Display statistics      |" << endl;
		cout << "|  x - Exit program            |" << endl;
		cout << "--------------------------------" << endl;
		cout << "Enter choice: ";
		cin >> choiceStr;
		cout << endl;
		if (choiceStr.length() == 0)
		{
			choice = 'e';
		}
		else
		{
			choice = choiceStr[0];
		}
		switch (choice)
		{
		case 'a':
		case 'A':
			display(tree);
			cout << "---------------------" << endl;
			cout << "Total words   : " << stats.total << endl;
			break;
		case 'f':
		case 'F':
			display(tree2);
			cout << "---------------------" << endl;
			cout << "Total words   : " << stats.total << endl;
			break;
		case 's':
		case 'S':
			cout << "Total words   : " << stats.total << endl;
			cout << "Distinct words: " << stats.distinct << endl;
			cout << "Unique words  : " << stats.unique << endl;
			cout << "Multiple words: " << stats.multiple << endl;
			cout << "-------------------------------------------" << endl;
			cout << setprecision(2) << fixed << "Distinct words as % of words       : " << percentage.distinct << "%" << endl;
			cout << setprecision(2) << fixed << "Unique words as % of total words   : " << percentage.uniqueWords << "%" << endl;
			cout << setprecision(2) << fixed << "Unique words as % of distinct words: " << percentage.uniqueDistincts << "%" << endl;
			cout << "-------------------------------------------" << endl;
			break;
		case 'x':
		case 'X':
			break;
		default:
			cout << "Error, invalid choice" << endl;
			break;
		}
	} while (choice != 'x');
}
Node* addNode(Node* tree, Node* toAdd) //Adding to tree
{
	if (tree == 0)
	{
		return toAdd;
	}
	else
	{
		if (toAdd->value.words < tree->value.words)
		{
			tree->pLeft = addNode(tree->pLeft, toAdd);
			return tree;
		}
		else
		{
			tree->pRight = addNode(tree->pRight, toAdd);
			return tree;
		}
	}
}
Node* addNodeFrequency(Node* tree, Node* toAdd) //Checking the frequency that a word shows up
{
	if (tree == 0)
	{
		return toAdd;
	}
	else
	{
		if (toAdd->value.frequency < tree->value.frequency)
		{
			tree->pLeft = addNodeFrequency(tree->pLeft, toAdd);
			return tree;
		}
		else
		{
			tree->pRight = addNodeFrequency(tree->pRight, toAdd);
			return tree;
		}
	}
}
Node* add(Node* tree, Display value) //Display
{
	Node* tempPtr = new Node;
	tempPtr->value = value;
	tempPtr->pLeft = 0;
	tempPtr->pRight = 0;
	return addNode(tree, tempPtr);
}
int countNodes(Node *root) //Count
{
	if (root == NULL)
	{
		return 0;
	}
	else
	{
		int count = 1;
		count += countNodes(root->pLeft);
		count += countNodes(root->pRight);
		return count;
	}
}
bool duplicate(Node *same, string word) //Counting duplicates
{
	while (true)
	{
		if (same == NULL)
		{
			return false;
		}
		else if (word == same->value.words)
		{
			return true;
		}
		else if (word < same->value.words)
		{
			same = same->pLeft;
		}
		else
		{
			same = same->pRight;
		}
	}
}
void display(Node* tree) //Displaying all words
{
	if (tree != 0)
	{
		display(tree->pLeft);
		cout << tree->value.words << " " << "'" << tree->value.frequency << "'" << endl;
		display(tree->pRight);
	}
}